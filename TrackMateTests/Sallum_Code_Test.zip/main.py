import torch
import cv2
import numpy as np
import time

# Load YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s')  # or yolov5m/yolov5l/yolov5x

# Set model to only detect 'dog' class
model.classes = [16]  # COCO class index for 'dog'

# Optional: Sample breed list (used if you're not loading a real classifier)
breed_list = [
    'Labrador', 'Golden Retriever', 'German Shepherd', 'Beagle',
    'Poodle', 'Bulldog', 'Boxer', 'Dalmatian', 'Chihuahua', 'Husky'
]

def fake_breed_classifier(crop):
    # Simulates a breed prediction
    import random
    breed = random.choice(breed_list)
    conf = round(random.uniform(0.75, 0.95), 2)
    return breed, conf

# Start video capture (change index if needed)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("❌ Could not open the camera.")
    exit()

print("✅ Camera started. Press 'q' to exit.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Failed to grab frame.")
        break

    # Run YOLOv5 detection
    results = model(frame)

    # Process results
    for *box, conf, cls in results.xyxy[0]:
        x1, y1, x2, y2 = map(int, box)
        dog_crop = frame[y1:y2, x1:x2]

        # Predict breed
        breed, breed_conf = fake_breed_classifier(dog_crop)

        label = f"{breed} ({breed_conf*100:.0f}%)"
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, label, (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    # Display the frame
    cv2.imshow("🐶 Dog Detection & Breed Classification", frame)

    # Press 'q' to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Clean up
cap.release()
cv2.destroyAllWindows()