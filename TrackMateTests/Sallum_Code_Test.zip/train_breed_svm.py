import os, pickle
import cv2
import numpy as np
from skimage.feature import hog
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# ------------- CONFIG -------------
DATASET_DIR = "path/to/your/dog_breeds_dataset"
# Your dataset should be:
# DATASET_DIR/
#    labrador/
#      img1.jpg
#      img2.jpg
#    pug/
#      img1.jpg
#      ...
# ----------------------------------

def extract_hog(img):
    img = cv2.resize(img, (128,128))
    return hog(img, orientations=9, pixels_per_cell=(8,8),
               cells_per_block=(2,2), feature_vector=True)

X, y = [], []
for breed in os.listdir(DATASET_DIR):
    bd_path = os.path.join(DATASET_DIR, breed)
    if not os.path.isdir(bd_path): continue
    for fn in os.listdir(bd_path):
        img = cv2.imread(os.path.join(bd_path, fn), cv2.IMREAD_GRAYSCALE)
        if img is None: continue
        X.append(extract_hog(img))
        y.append(breed)

# Encode labels
le = LabelEncoder()
y_enc = le.fit_transform(y)

# Train/Test split
X_train, X_test, y_train, y_test = train_test_split(X, y_enc,
                                                    test_size=0.2,
                                                    random_state=42)

# Train an SVM with probability estimates
clf = SVC(kernel='linear', probability=True, random_state=42)
clf.fit(X_train, y_train)
print("Train acc:", clf.score(X_train, y_train))
print("Test  acc:", clf.score(X_test, y_test))

# Save model + label encoder
with open("breed_svm.pkl", "wb") as f:
    pickle.dump({'model': clf, 'labels': le}, f)

print("Saved breed_svm.pkl")
