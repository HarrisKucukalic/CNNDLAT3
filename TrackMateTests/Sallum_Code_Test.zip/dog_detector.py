import cv2
import cvlib as cv
from cvlib.object_detection import draw_bbox

def find_camera_index():
    # brute‑force test first few indices
    for i in range(4):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            ret, _ = cap.read()
            cap.release()
            if ret:
                print(f"[+] camera {i} OK")
                return i
    raise RuntimeError("No working camera index found")

def main():
    cam_idx = find_camera_index()
    cap = cv2.VideoCapture(cam_idx)
    print(f"Using camera index {cam_idx}. Press 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # detect_common_objects knows about 'dog'
        bbox, labels, confs = cv.detect_common_objects(
            frame, model="yolov4-tiny",  # fast tiny‐YOLO
            enable_gpu=False  # CPU mode
        )

        # filter just dogs
        dog_boxes = [b for b, l in zip(bbox, labels) if l == "dog"]
        dog_confs = [c for c, l in zip(confs, labels) if l == "dog"]

        # draw only dog bboxes
        out = draw_bbox(frame, dog_boxes, ["dog"]*len(dog_boxes), dog_confs)
        cv2.imshow("Dog Detector", out)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
