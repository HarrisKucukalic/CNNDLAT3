import cv2, time

def list_cams(max_test=5):
    cams=[]
    for i in range(max_test):
        cap=cv2.VideoCapture(i)
        if cap.isOpened():
            cams.append(i); cap.release()
    return cams

def detect_iphone_camera():
    cams = list_cams()
    # prefer devices ≥1 (external)
    for ci in cams:
        if ci>0: return ci
    return cams[0] if cams else None

def get_camera_stream(idx=None):
    if idx is None: idx = detect_iphone_camera()
    cap = cv2.VideoCapture(idx)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,720)
    return cap if cap.isOpened() else None
