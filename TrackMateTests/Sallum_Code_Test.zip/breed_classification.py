import cv2, pickle, numpy as np

class DogBreedClassifier:
    def __init__(self, svm_path="breed_svm.pkl"):
        data = pickle.load(open(svm_path,"rb"))
        self.model = data['model']
        self.le    = data['labels']

    def classify(self, roi):
        # roi: BGR image of the dog region
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        feat = cv2.resize(gray,(128,128))
        feat = feat.flatten()  # or repeat HOG for better results
        # Here we assume features are HOG; if you trained on HOG, re-extract HOG
        probs = self.model.predict_proba([feat])[0]
        idx = np.argmax(probs)
        return self.le.inverse_transform([idx])[0], float(probs[idx])
