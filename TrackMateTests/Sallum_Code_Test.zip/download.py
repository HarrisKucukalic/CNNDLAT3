import cv2
import numpy as np
from ultralytics import YOLO

class DogDetector:
    def __init__(self):
        self.model = YOLO("yolov8n-dog.pt")  # Auto-downloads if missing
        self.dog_class_id = 16  # COCO class ID for 'dog'
    
    def detect(self, frame):
        results = self.model(frame, verbose=False)
        detections = []
        
        for box in results[0].boxes:
            if int(box.cls) == self.dog_class_id:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                detections.append({
                    'box': [x1, y1, x2-x1, y2-y1],
                    'confidence': float(box.conf)
                })
        return detections

# Usage example
detector = DogDetector()
cap = cv2.VideoCapture(0)  # Use 1 for phone camera

while True:
    ret, frame = cap.read()
    detections = detector.detect(frame)
    
    for det in detections:
        x, y, w, h = det['box']
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 2)
    
    cv2.imshow("Dog Detection", frame)
    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()