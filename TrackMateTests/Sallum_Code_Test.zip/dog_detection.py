import cv2, numpy as np, os

class YOLODogDetector:
    def __init__(self, cfg="yolov3-tiny.cfg",
                 weights="yolov3-tiny.weights",
                 names="coco.names", conf_th=0.5, nms_th=0.4):
        assert os.path.exists(cfg) and os.path.exists(weights) and os.path.exists(names)
        with open(names,'r') as f: classes = [l.strip() for l in f]
        self.dog_id = classes.index("dog")
        self.net = cv2.dnn.readNetFromDarknet(cfg, weights)
        layers = self.net.getLayerNames()
        self.out_layers = [layers[i-1] for i in self.net.getUnconnectedOutLayers().flatten()]
        self.conf_th, self.nms_th = conf_th, nms_th

    def detect(self, frame):
        h,w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1/255, (416,416), swapRB=True, crop=False)
        self.net.setInput(blob)
        outs = self.net.forward(self.out_layers)
        boxes,confs = [],[]
        for out in outs:
            for det in out:
                scores = det[5:]
                cid = np.argmax(scores)
                if cid!=self.dog_id: continue
                conf = scores[cid]
                if conf<self.conf_th: continue
                cx,cy,fw,fh = (det[0:4]*[w,h,w,h]).astype(int)
                x,y = int(cx-fw/2), int(cy-fh/2)
                boxes.append([x,y,fw,fh]); confs.append(float(conf))
        idxs = cv2.dnn.NMSBoxes(boxes,confs,self.conf_th,self.nms_th)
        return [ (boxes[i][0],boxes[i][1],boxes[i][2],boxes[i][3], confs[i])
                 for i in idxs.flatten() ] if len(idxs)>0 else []
